﻿using UnityEngine;
using System.Collections;

public class MoveUp : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}

    void OnTriggerStay2D(Collider2D col)
    {
        //if (col.gameObject.layer == 9)
        //{
        //    mainscript.Instance.dropUp();
        //}
    }
	
	// Update is called once per frame
	void Update () {
	
	}
}
