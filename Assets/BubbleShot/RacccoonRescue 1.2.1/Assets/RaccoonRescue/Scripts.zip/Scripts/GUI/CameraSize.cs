﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;
using System;

public class CameraSize : MonoBehaviour
{

    // Use this for initialization
    void Start()
    {
        if (SceneManager.GetActiveScene() == SceneManager.GetSceneByName("map"))
        {
            Application.targetFrameRate = 60;
            float aspect = (float)Screen.height / (float)Screen.width;
            aspect = (float)Math.Round(aspect, 2);
            if (aspect == 1.6f)
                GetComponent<Camera>().orthographicSize = 12.23f;                    //16:10
            else if (aspect == 1.78f)
                GetComponent<Camera>().orthographicSize = 13.6f;    //16:9
            else if (aspect == 1.5f)
                GetComponent<Camera>().orthographicSize = 11.46f;                  //3:2
            else if (aspect == 1.33f)
                GetComponent<Camera>().orthographicSize = 10.16f;                  //4:3
            else if (aspect == 1.67f)
                GetComponent<Camera>().orthographicSize = 12.68f;                  //5:3
            else if (aspect == 1.25f)
                GetComponent<Camera>().orthographicSize = 9.5f;                  //5:4

        }
    }

}
