﻿using UnityEngine;
using System.Collections;

public class Slot : MonoBehaviour {
	public string id;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
